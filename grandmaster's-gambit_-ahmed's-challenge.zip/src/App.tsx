/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect, useRef } from 'react';
import { Chess, Move } from 'chess.js';
import { motion, AnimatePresence } from 'motion/react';
import { Trophy, Skull, RefreshCcw, Info, ChevronRight } from 'lucide-react';

declare global {
  interface Window {
    Chessboard: any;
    ChessBoard: any;
    $: any;
    jQuery: any;
  }
}

// --- Chess AI Logic ---

const PIECE_VALUES: Record<string, number> = {
  p: 10,
  n: 30,
  b: 30,
  r: 50,
  q: 90,
  k: 900,
};

const evaluateBoard = (game: Chess, isAhmed: boolean): number => {
  let totalEvaluation = 0;
  const board = game.board();
  
  // Checkmate is the ultimate goal
  if (game.isCheckmate()) {
    // If it's Ahmed's turn and he checkmated the player, return a huge value
    return game.turn() === 'b' ? 10000 : -10000;
  }

  for (let i = 0; i < 8; i++) {
    for (let j = 0; j < 8; j++) {
      const piece = board[i][j];
      if (piece) {
        let value = PIECE_VALUES[piece.type] || 0;
        
        // Ahmed is extra aggressive towards Queen and Rook
        if (isAhmed && piece.color === 'w') {
          if (piece.type === 'q') value += 50; // Extra incentive to capture Queen
          if (piece.type === 'r') value += 20; // Extra incentive to capture Rook
        }

        totalEvaluation += piece.color === 'w' ? value : -value;
      }
    }
  }
  return totalEvaluation;
};

const minimax = (game: Chess, depth: number, alpha: number, beta: number, isMaximizingPlayer: boolean, isAhmed: boolean): number => {
  if (depth === 0 || game.isGameOver()) return -evaluateBoard(game, isAhmed);

  const moves = game.moves();
  if (isMaximizingPlayer) {
    let bestEval = -Infinity;
    for (const move of moves) {
      game.move(move);
      const evaluation = minimax(game, depth - 1, alpha, beta, !isMaximizingPlayer, isAhmed);
      game.undo();
      bestEval = Math.max(bestEval, evaluation);
      alpha = Math.max(alpha, evaluation);
      if (beta <= alpha) break;
    }
    return bestEval;
  } else {
    let bestEval = Infinity;
    for (const move of moves) {
      game.move(move);
      const evaluation = minimax(game, depth - 1, alpha, beta, !isMaximizingPlayer, isAhmed);
      game.undo();
      bestEval = Math.min(bestEval, evaluation);
      beta = Math.min(beta, evaluation);
      if (beta <= alpha) break;
    }
    return bestEval;
  }
};

const getBestMove = (game: Chess, depth: number, isAhmed: boolean): string => {
  const moves = game.moves();
  
  // Check for immediate checkmate first
  for (const move of moves) {
    game.move(move);
    if (game.isCheckmate()) {
      game.undo();
      return move;
    }
    game.undo();
  }

  let bestMove = moves[0];
  let bestValue = -Infinity;

  for (const move of moves) {
    game.move(move);
    const boardValue = minimax(game, depth - 1, -Infinity, Infinity, false, isAhmed);
    game.undo();
    if (boardValue > bestValue) {
      bestValue = boardValue;
      bestMove = move;
    }
  }
  return bestMove;
};

// --- Main Component ---

export default function App() {
  const [game, setGame] = useState(new Chess());
  const [level, setLevel] = useState(1);
  const [opponentName, setOpponentName] = useState('Novice Bot');
  const [status, setStatus] = useState('Your Turn');
  const [isJumpscare, setIsJumpscare] = useState(false);
  const [hasStarted, setHasStarted] = useState(false);
  const [isLibReady, setIsLibReady] = useState(false);
  const boardRef = useRef<any>(null);
  const gameRef = useRef(game);
  const jumpscareAudioRef = useRef<HTMLAudioElement | null>(null);

  useEffect(() => {
    const checkLib = () => {
      if (window.Chessboard || window.ChessBoard) {
        setIsLibReady(true);
      } else {
        setTimeout(checkLib, 100);
      }
    };
    checkLib();
  }, []);

  useEffect(() => {
    gameRef.current = game;
  }, [game]);

  useEffect(() => {
    if (!hasStarted || !isLibReady) return;

    const ChessboardFn = window.Chessboard || window.ChessBoard;
    if (!ChessboardFn) return;

    const removeGreySquares = () => {
      const $ = window.$;
      if ($) {
        $('#chess-board .square-55d63').css('background', '');
      }
    };

    const greySquare = (square: string) => {
      const $ = window.$;
      if (!$) return;
      const $square = $('#chess-board .square-' + square);

      let background = '#a9a9a9';
      if ($square.hasClass('black-3c85d')) {
        background = '#696969';
      }

      $square.css('background', background);
    };

    // Initialize board
    const config = {
      draggable: true,
      position: 'start',
      pieceTheme: 'https://unpkg.com/chessboardjs@0.0.1/www/img/chesspieces/wikipedia/{piece}.png',
      onDragStart: (source: string, piece: string) => {
        console.log('Drag Start:', source, piece);
        if (gameRef.current.isGameOver()) return false;
        if (piece.search(/^b/) !== -1) return false;
      },
      onMouseoverSquare: (square: string, piece: string) => {
        // get list of possible moves for this square
        const moves = gameRef.current.moves({
          square: square as any,
          verbose: true
        });

        // exit if there are no moves available for this square
        if (moves.length === 0) return;

        // highlight the square they moused over
        greySquare(square);

        // highlight the possible squares for this piece
        for (let i = 0; i < moves.length; i++) {
          greySquare(moves[i].to);
        }
      },
      onMouseoutSquare: () => {
        removeGreySquares();
      },
      onDrop: (source: string, target: string) => {
        removeGreySquares();
        try {
          const move = gameRef.current.move({
            from: source,
            to: target,
            promotion: 'q',
          });

          if (move === null) return 'snapback';

          setGame(new Chess(gameRef.current.fen()));
          updateStatus();
          window.setTimeout(makeAiMove, 250);
        } catch (e) {
          return 'snapback';
        }
      },
      onSnapEnd: () => {
        boardRef.current.position(gameRef.current.fen());
      },
    };

    boardRef.current = ChessboardFn('chess-board', config);

    const handleResize = () => {
      if (boardRef.current) boardRef.current.resize();
    };

    window.addEventListener('resize', handleResize);
    setTimeout(handleResize, 100);

    return () => {
      if (boardRef.current) boardRef.current.destroy();
      window.removeEventListener('resize', handleResize);
    };
  }, [hasStarted]);

  useEffect(() => {
    if (!hasStarted) return;
    const $ = window.$;
    if (!$) return;

    if (level === 3) {
      setOpponentName('Ahmed El Addawy');
      // Update board theme to "intense"
      $('.square-55d63').css('background-color', '#27272a');
      $('.white-1e1d7').css('background-color', '#3f3f46');
      $('.black-3c85d').css('background-color', '#7f1d1d'); // Intense red for black squares
    } else {
      setOpponentName(level === 1 ? 'Novice Bot' : 'Intermediate Bot');
      $('.black-3c85d').css('background-color', '#52525b');
    }
  }, [level, hasStarted]);

  const updateStatus = () => {
    const current = gameRef.current;
    if (current.isCheckmate()) {
      setStatus(`Checkmate! ${current.turn() === 'w' ? 'Black' : 'White'} wins.`);
      if (current.turn() === 'w' && level === 3) {
        setTimeout(triggerJumpscare, 500);
      }
    } else if (current.isDraw()) {
      setStatus('Draw!');
    } else {
      setStatus(current.turn() === 'w' ? 'Your Turn' : "Opponent's Thinking...");
    }
  };

  const makeAiMove = () => {
    const current = gameRef.current;
    if (current.isGameOver()) return;

    let move: string | Move;
    const moves = current.moves();

    if (level === 1 || level === 2) {
      // Level 1 & 2: Random move
      move = moves[Math.floor(Math.random() * moves.length)];
    } else {
      // Level 3: Ahmed - Impossible Genius
      move = getBestMove(current, 3, true); // Depth 3 is fast enough and strong with Ahmed logic
    }

    current.move(move);
    boardRef.current.position(current.fen());
    setGame(new Chess(current.fen()));
    updateStatus();
  };

  const triggerJumpscare = () => {
    setIsJumpscare(true);
    if (jumpscareAudioRef.current) {
      jumpscareAudioRef.current.volume = 1.0;
      jumpscareAudioRef.current.play().catch(e => console.error("Audio play failed", e));
    }
  };

  const resetGame = () => {
    const newGame = new Chess();
    gameRef.current = newGame;
    setGame(newGame);
    if (boardRef.current) boardRef.current.position('start');
    setStatus('Your Turn');
    setIsJumpscare(false);
  };

  const nextLevel = () => {
    if (level < 3) {
      setLevel(level + 1);
      resetGame();
    }
  };

  if (!hasStarted) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-zinc-950 p-4">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="max-w-md w-full bg-zinc-900 border border-zinc-800 p-8 rounded-3xl text-center space-y-6 shadow-2xl"
        >
          <div className="w-20 h-20 bg-red-500/10 rounded-full flex items-center justify-center mx-auto mb-4">
            <Skull className="w-10 h-10 text-red-500" />
          </div>
          <h1 className="text-3xl font-bold text-white tracking-tight">Grandmaster's Gambit</h1>
          <p className="text-zinc-400 leading-relaxed">
            A three-level chess challenge. Survive the novice bots to face the ultimate opponent: <span className="text-red-500 font-bold">Ahmed El Addawy</span>.
          </p>
          <button
            onClick={() => setHasStarted(true)}
            disabled={!isLibReady}
            className={`w-full py-4 rounded-2xl font-bold text-lg transition-all active:scale-95 shadow-lg ${
              isLibReady 
                ? 'bg-red-600 hover:bg-red-500 text-white shadow-red-600/20' 
                : 'bg-zinc-800 text-zinc-500 cursor-not-allowed'
            }`}
          >
            {isLibReady ? 'Enter the Challenge' : 'Loading Assets...'}
          </button>
          <p className="text-[10px] text-zinc-600 uppercase tracking-widest">Headphones Recommended</p>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-4 bg-zinc-950 font-sans relative">
      {/* Jumpscare Overlay */}
      <AnimatePresence>
        {isJumpscare && (
          <motion.div
            initial={{ scale: 0.5, opacity: 0 }}
            animate={{ scale: 1.2, opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[9999] bg-black flex items-center justify-center overflow-hidden"
          >
            <img 
              src="https://images.unsplash.com/photo-1509248961158-e54f6934749c?q=80&w=1000&auto=format&fit=crop" 
              alt="Jumpscare" 
              className="w-full h-full object-cover"
              referrerPolicy="no-referrer"
            />
            <audio 
              ref={jumpscareAudioRef}
              src="https://www.soundjay.com/human/sounds/scream-01.mp3" 
              autoPlay
            />
          </motion.div>
        )}
      </AnimatePresence>

      <div className="max-w-4xl w-full grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left Panel: Info */}
        <div className="lg:col-span-1 space-y-6">
          <div className="bg-zinc-900/50 border border-zinc-800 p-6 rounded-2xl backdrop-blur-sm">
            <div className="flex items-center gap-3 mb-4">
              <div className="p-2 bg-red-500/10 rounded-lg">
                <Skull className="w-6 h-6 text-red-500" />
              </div>
              <div>
                <h1 className="text-xl font-bold tracking-tight">Grandmaster's Gambit</h1>
                <p className="text-xs text-zinc-500 uppercase tracking-widest font-medium">Survival Challenge</p>
              </div>
            </div>

            <div className="space-y-4">
              <div className="flex items-center justify-between p-3 bg-zinc-800/50 rounded-xl border border-zinc-700/50">
                <span className="text-sm text-zinc-400">Current Level</span>
                <span className="text-lg font-bold text-white">Level {level}</span>
              </div>
              <div className="flex items-center justify-between p-3 bg-zinc-800/50 rounded-xl border border-zinc-700/50">
                <span className="text-sm text-zinc-400">Opponent</span>
                <span className={`text-sm font-bold ${level === 3 ? 'text-red-500 animate-pulse' : 'text-blue-400'}`}>
                  {opponentName}
                </span>
              </div>
            </div>
          </div>

          <div className="bg-zinc-900/50 border border-zinc-800 p-6 rounded-2xl">
            <h3 className="text-sm font-semibold mb-3 flex items-center gap-2">
              <Info className="w-4 h-4 text-zinc-400" />
              Game Status
            </h3>
            <p className={`text-lg font-medium ${status.includes('Checkmate') ? 'text-red-500' : 'text-zinc-300'}`}>
              {status}
            </p>
          </div>

          <div className="flex flex-col gap-3">
            <button
              onClick={resetGame}
              className="flex items-center justify-center gap-2 w-full py-3 bg-zinc-800 hover:bg-zinc-700 text-white rounded-xl transition-all active:scale-95 font-medium"
            >
              <RefreshCcw className="w-4 h-4" />
              Reset Board
            </button>
            {level < 3 && (
              <button
                onClick={nextLevel}
                className="flex items-center justify-center gap-2 w-full py-3 bg-blue-600 hover:bg-blue-500 text-white rounded-xl transition-all active:scale-95 font-medium"
              >
                Next Level
                <ChevronRight className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>

        {/* Right Panel: Board */}
        <div className="lg:col-span-2 flex items-center justify-center">
          <div className="relative group">
            <div className={`absolute -inset-1 bg-gradient-to-r ${level === 3 ? 'from-red-600 to-orange-600' : 'from-blue-600 to-indigo-600'} rounded-lg blur opacity-25 group-hover:opacity-50 transition duration-1000 group-hover:duration-200`}></div>
            <div 
              id="chess-board" 
              className="relative w-[320px] sm:w-[450px] md:w-[500px] bg-zinc-900 rounded-lg border-4 border-zinc-800 shadow-2xl"
            ></div>
          </div>
        </div>
      </div>

      <footer className="mt-12 text-zinc-600 text-xs flex items-center gap-4">
        <span className="flex items-center gap-1">
          <Trophy className="w-3 h-3" />
          Beat Level 3 to Win
        </span>
        <span className="w-1 h-1 bg-zinc-800 rounded-full"></span>
        <span>Warning: High Difficulty Ahead</span>
      </footer>
    </div>
  );
}
